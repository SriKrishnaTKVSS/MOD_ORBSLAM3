% Smooth Robust Differentiators
% Version 1.1   03-22-2014
% Files
%   robustDiff - differentiates using smooth noise-robust differentiation formula
%   robustDiffOneSide - differentiates using smooth noise-robust one sided differentiation formula
