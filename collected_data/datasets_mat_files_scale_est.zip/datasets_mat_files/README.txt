Total 16 datasets
Each dataset has two .mat files containing Mocap and orbslam data converted to mocap frame.
.mat file contains timestamps starting from 0 @ 30 Hz and x,y,z and angles data.
